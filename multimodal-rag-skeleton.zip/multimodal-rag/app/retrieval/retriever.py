"""
Retrieval layer (Review-1 Section 5, "top-k search using the combined
database of images and texts"). Queries both sub-indexes and merges results
by similarity score into one ranked evidence list.
"""
from dataclasses import dataclass

from app.config import settings
from app.embeddings.image_embedder import embed_text_in_clip_space
from app.embeddings.text_embedder import embed_text
from app.indexing.vector_store import VectorStore
from app.models.schemas import Chunk


@dataclass
class RetrievedEvidence:
    chunk: Chunk
    score: float  # lower L2 distance = more relevant (HNSW default metric)


def retrieve(
    store: VectorStore,
    question: str,
    k: int = None,
    document_id: str | None = None,
) -> list[RetrievedEvidence]:
    k = k or settings.top_k

    text_query_vec = embed_text(question)
    clip_query_vec = embed_text_in_clip_space(question)

    text_hits = store.search_text(text_query_vec, k)
    image_hits = store.search_images(clip_query_vec, k)

    merged = [RetrievedEvidence(chunk=c, score=s) for c, s in text_hits + image_hits]

    if document_id:
        merged = [e for e in merged if e.chunk.document_id == document_id]

    # Lower distance = better match; take the overall top-k across both modalities.
    merged.sort(key=lambda e: e.score)
    return merged[:k]
