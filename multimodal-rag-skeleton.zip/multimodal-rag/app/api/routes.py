"""
Serving layer (Review-1 Section 5, "FastAPI service ... upload document,
question submission, answer retrieval"). Keeps a single in-memory
VectorStore for the demo; swap `get_store` for a DB/disk-backed singleton
if you need persistence across restarts (build_index.py already persists
to data/indexes/, so on startup you can VectorStore.load() that path).
"""
import shutil
import tempfile
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile

from app.config import settings
from app.embeddings.image_embedder import embed_image
from app.embeddings.text_embedder import embed_text
from app.generation.vlm_generator import generate_answer
from app.indexing.vector_store import VectorStore
from app.ingestion.pdf_parser import parse_pdf
from app.models.schemas import AskRequest, AskResponse, EmbeddedChunk, UploadResponse
from app.retrieval.retriever import retrieve

router = APIRouter()

# --- Simple process-wide store; see docstring for persistence notes. ---
_store: VectorStore | None = None


def get_store() -> VectorStore:
    global _store
    if _store is None:
        index_path = settings.index_dir
        if (index_path / "metadata.pkl").exists():
            _store = VectorStore.load(index_path)
        else:
            _store = VectorStore()
    return _store


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/upload", response_model=UploadResponse)
async def upload_document(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = Path(tmp.name)

    try:
        chunks = parse_pdf(tmp_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    embedded = []
    for chunk in chunks:
        if chunk.modality == "image" and chunk.image_path:
            vec = embed_image(chunk.image_path)
        else:
            vec = embed_text(chunk.content)
        embedded.append(EmbeddedChunk(chunk=chunk, vector=vec))

    store = get_store()
    store.add(embedded)
    store.save(settings.index_dir)

    document_id = chunks[0].document_id if chunks else Path(file.filename).stem
    return UploadResponse(
        document_id=document_id,
        filename=file.filename,
        page_count=len({c.page_number for c in chunks}),
        text_chunks=sum(1 for c in chunks if c.modality == "text"),
        table_chunks=sum(1 for c in chunks if c.modality == "table"),
        image_chunks=sum(1 for c in chunks if c.modality == "image"),
    )


@router.post("/ask", response_model=AskResponse)
async def ask_question(request: AskRequest):
    store = get_store()
    evidence = retrieve(
        store, request.question, k=request.top_k, document_id=request.document_id
    )
    return generate_answer(request.question, evidence)
