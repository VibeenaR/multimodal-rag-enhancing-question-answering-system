from fastapi import FastAPI

from app.api.routes import router

app = FastAPI(
    title="Multimodal RAG API",
    description="Cross-modal document QA over text, tables and images.",
    version="0.1.0",
)

app.include_router(router)


@app.get("/")
def root():
    return {
        "message": "Multimodal RAG API is running.",
        "docs": "/docs",
        "endpoints": ["/upload", "/ask", "/health"],
    }
