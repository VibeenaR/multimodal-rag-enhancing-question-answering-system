"""
Generation layer (Review-1 Section 5, "generation layer ... produces an
answer based on the retrieved data using a vision-language model" and
"That answer is then cited"). This targets the Anthropic Messages API as
the VLM; swap the client call for GPT-4V / Gemini / an open VLM if your
guide prefers a different model — only `_call_vlm` needs to change.
"""
import base64
from pathlib import Path

import anthropic

from app.config import settings
from app.models.schemas import AskResponse, Citation
from app.retrieval.retriever import RetrievedEvidence

_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)


def _build_evidence_blocks(evidence: list[RetrievedEvidence]) -> list[dict]:
    """Turns retrieved Chunks into Anthropic message content blocks —
    text/table chunks as text, image chunks as base64 images — each
    labeled with its source so the model can cite correctly."""
    blocks = []
    for i, ev in enumerate(evidence):
        chunk = ev.chunk
        label = f"[Source {i+1}: document={chunk.document_id}, page={chunk.page_number}, type={chunk.modality}]"

        if chunk.modality == "image" and chunk.image_path:
            image_bytes = Path(chunk.image_path).read_bytes()
            b64 = base64.standard_b64encode(image_bytes).decode("utf-8")
            ext = Path(chunk.image_path).suffix.lstrip(".") or "png"
            blocks.append({"type": "text", "text": label})
            blocks.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": f"image/{ext}",
                        "data": b64,
                    },
                }
            )
        else:
            blocks.append({"type": "text", "text": f"{label}\n{chunk.content}"})

    return blocks


def _call_vlm(question: str, evidence_blocks: list[dict]) -> str:
    system_prompt = (
        "You answer questions using ONLY the evidence provided below. "
        "Every claim in your answer must be traceable to a numbered source. "
        "If the evidence does not contain the answer, say so explicitly — "
        "do not guess. End your answer with a line: "
        "'Sources: [n, n, ...]' listing the source numbers you relied on."
    )

    message = _client.messages.create(
        model=settings.vlm_model,
        max_tokens=800,
        system=system_prompt,
        messages=[
            {
                "role": "user",
                "content": evidence_blocks
                + [{"type": "text", "text": f"Question: {question}"}],
            }
        ],
    )
    return "".join(block.text for block in message.content if block.type == "text")


def generate_answer(question: str, evidence: list[RetrievedEvidence]) -> AskResponse:
    if not evidence:
        return AskResponse(
            answer="No relevant evidence was found in the indexed documents.",
            citations=[],
            retrieved_chunk_ids=[],
        )

    blocks = _build_evidence_blocks(evidence)
    raw_answer = _call_vlm(question, blocks)

    citations = [
        Citation(
            document_id=ev.chunk.document_id,
            page_number=ev.chunk.page_number,
            modality=ev.chunk.modality,
        )
        for ev in evidence
    ]

    return AskResponse(
        answer=raw_answer,
        citations=citations,
        retrieved_chunk_ids=[ev.chunk.chunk_id for ev in evidence],
    )
