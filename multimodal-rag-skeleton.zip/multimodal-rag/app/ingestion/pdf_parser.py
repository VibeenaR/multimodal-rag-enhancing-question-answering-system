"""
Ingestion layer (Review-1, Section 5, "ingestion layer").

Parses a PDF into page-tagged Chunks:
  - text blocks  (PyMuPDF)
  - tables       (pdfplumber, falling back to camelot for ruled tables)
  - images       (PyMuPDF, saved to disk for the CLIP embedder to read)

Each chunk keeps its document_id and page_number so citations in the
generation layer can point back to the exact source page.
"""
import uuid
from pathlib import Path

import fitz  # PyMuPDF
import pdfplumber

from app.config import settings
from app.models.schemas import Chunk


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


def extract_text_chunks(doc: fitz.Document, document_id: str) -> list[Chunk]:
    """One chunk per page (or per paragraph block if you want finer granularity —
    see the commented alternative below)."""
    chunks = []
    for page_index in range(len(doc)):
        page = doc[page_index]
        text = page.get_text("text").strip()
        if not text:
            continue
        chunks.append(
            Chunk(
                chunk_id=_new_id(),
                document_id=document_id,
                page_number=page_index + 1,
                modality="text",
                content=text,
            )
        )

        # --- Finer-grained alternative (paragraph-level chunks) ---
        # blocks = page.get_text("blocks")
        # for b in blocks:
        #     block_text = b[4].strip()
        #     if block_text:
        #         chunks.append(Chunk(_new_id(), document_id, page_index + 1,
        #                              "text", block_text))
    return chunks


def extract_table_chunks(pdf_path: Path, document_id: str) -> list[Chunk]:
    """Serializes each detected table to a markdown-ish text block so it can
    share the text embedder / same vector space as prose."""
    chunks = []
    with pdfplumber.open(pdf_path) as pdf:
        for page_index, page in enumerate(pdf.pages):
            tables = page.extract_tables()
            for table in tables:
                if not table or not any(any(cell for cell in row) for row in table):
                    continue
                serialized = _table_to_text(table)
                chunks.append(
                    Chunk(
                        chunk_id=_new_id(),
                        document_id=document_id,
                        page_number=page_index + 1,
                        modality="table",
                        content=serialized,
                    )
                )
    return chunks


def _table_to_text(table: list[list[str | None]]) -> str:
    rows = []
    for row in table:
        cells = [str(c).strip() if c else "" for c in row]
        rows.append(" | ".join(cells))
    return "\n".join(rows)


def extract_image_chunks(
    doc: fitz.Document, document_id: str, output_dir: Path
) -> list[Chunk]:
    """Saves each embedded image to disk (CLIP needs a file/array, not raw bytes
    in the DB) and records its source page."""
    output_dir.mkdir(parents=True, exist_ok=True)
    chunks = []
    for page_index in range(len(doc)):
        page = doc[page_index]
        for img_index, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            ext = base_image["ext"]
            image_path = output_dir / f"{document_id}_p{page_index+1}_{img_index}.{ext}"
            image_path.write_bytes(image_bytes)

            chunks.append(
                Chunk(
                    chunk_id=_new_id(),
                    document_id=document_id,
                    page_number=page_index + 1,
                    modality="image",
                    content=f"[image on page {page_index+1}]",
                    image_path=str(image_path),
                )
            )
    return chunks


def parse_pdf(pdf_path: str | Path) -> list[Chunk]:
    """Top-level ingestion entrypoint: PDF path -> list of page-tagged Chunks
    covering text, tables and images."""
    pdf_path = Path(pdf_path)
    document_id = pdf_path.stem

    doc = fitz.open(pdf_path)
    try:
        text_chunks = extract_text_chunks(doc, document_id)
        image_chunks = extract_image_chunks(
            doc, document_id, settings.processed_dir / "images"
        )
    finally:
        doc.close()

    table_chunks = extract_table_chunks(pdf_path, document_id)

    return text_chunks + table_chunks + image_chunks


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 2:
        print("Usage: python -m app.ingestion.pdf_parser <path_to_pdf>")
        raise SystemExit(1)

    result = parse_pdf(sys.argv[1])
    print(f"Extracted {len(result)} chunks:")
    for c in result[:10]:
        print(f"  [{c.modality}] page {c.page_number}: {c.content[:80]!r}")
