"""
Data models mirroring the class diagram in Review-1:
Document -> Page -> {TextChunk, ImageChunk, TableChunk} -> Embedding
Retriever -> VLMGenerator -> Answer -> Citation
"""
from dataclasses import dataclass
from typing import Literal
from pydantic import BaseModel, Field

Modality = Literal["text", "table", "image"]


# ---------- Internal ingestion/indexing dataclasses ----------

@dataclass
class Chunk:
    """A single retrievable unit: a text block, a table (serialized to text),
    or an image, always tagged with its source document/page."""
    chunk_id: str
    document_id: str
    page_number: int
    modality: Modality
    content: str            # raw text, or table-as-text, or an OCR/caption stub for images
    image_path: str | None = None  # set only when modality == "image"


@dataclass
class EmbeddedChunk:
    chunk: Chunk
    vector: list[float]


# ---------- API request/response models ----------

class UploadResponse(BaseModel):
    document_id: str
    filename: str
    page_count: int
    text_chunks: int
    table_chunks: int
    image_chunks: int


class AskRequest(BaseModel):
    document_id: str | None = None  # None -> search across all indexed documents
    question: str
    top_k: int = 5


class Citation(BaseModel):
    document_id: str
    page_number: int
    modality: Modality


class AskResponse(BaseModel):
    answer: str
    citations: list[Citation]
    retrieved_chunk_ids: list[str] = Field(default_factory=list)
