"""
Central configuration for the Multimodal RAG system.
All paths and model identifiers referenced elsewhere in the app come from here,
so swapping a model or dataset location is a one-line change.
"""
from pathlib import Path
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- Paths ---
    project_root: Path = Path(__file__).resolve().parent.parent
    raw_pdf_dir: Path = project_root / "data" / "raw_pdfs"
    processed_dir: Path = project_root / "data" / "processed"
    index_dir: Path = project_root / "data" / "indexes"

    # --- Embedding models (must match Review-1 proposal) ---
    text_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    clip_model_name: str = "ViT-B-32"
    clip_pretrained: str = "openai"

    # --- Embedding dimensions ---
    # MiniLM-L6 -> 384-d, CLIP ViT-B/32 -> 512-d.
    # These differ, so the index either (a) keeps two FAISS indexes under one
    # retrieval API, or (b) projects both into a shared dimension with a
    # learned/linear projection head. Default here is (a) — see vector_store.py.
    text_embedding_dim: int = 384
    image_embedding_dim: int = 512

    # --- FAISS ---
    faiss_index_type: str = "HNSW"  # "HNSW" or "IVF_PQ" per your architecture diagram
    hnsw_m: int = 32

    # --- Retrieval ---
    top_k: int = 5

    # --- Generation ---
    vlm_model: str = "claude-sonnet-4-6"
    anthropic_api_key: str = ""  # set via .env

    # --- DocVQA dataset ---
    docvqa_hf_id: str = "pixparse/docvqa-single-page-questions"

    class Config:
        env_file = ".env"


settings = Settings()
